﻿import datetime
from croniter import croniter

from utils.sqs import send_message
from models.jobs import Jobs



def check_and_run_job():
    run_jobs = []
    data = {}
    now = datetime.datetime.now()
    d1 = datetime.datetime(2021, 8, 20, 17, 50, 00)

    job_list = Jobs.query.all()
    for job in job_list:
        cron = croniter(job.cron, now)
        job_next_time = cron.get_next(datetime.datetime)
        if job_next_time == d1:
            data.update({'methods': job.methods})
            send_message(data)

    return True


# def save_job_excute_time():
#     return

