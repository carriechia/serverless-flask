import datetime
import requests
from scheduler import scheduler
from models.users import User
from utils.database import db


def line_notify(event, context):
    headers = {
        'Authorization': 'Bearer QQtzh0zAgbBP2G7tGzUKr8qllTp7sLA1636fD8qDoxx',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    r = requests.post('https://notify-api.line.me/api/notify',
                      headers=headers,
                      data={'message': 'Hello'})


# def task(a, b):
#     print(str(datetime.datetime.now()) + ' execute task ' + '{}+{}={}'.format(a, b, a + b))


# # interval example
# @scheduler.task('interval', id='do_job_1', seconds=1, misfire_grace_time=900)
# def job1():
#     print('Job 1 executed')


# # interval example l
# @scheduler.task('interval', id='do_job_2', seconds=2, misfire_grace_time=900)
# def job1():
#     print('Job 1 executed heeeeeeo')

# @scheduler.task('interval', id='do_show_users', seconds=2, misfire_grace_time=900)
def show_users():
    """Print all users."""
    users = User.query.all()
    print('aaaaaa', users)