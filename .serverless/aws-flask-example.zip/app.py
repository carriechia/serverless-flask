from flask import Flask
from utils.database import db
from config import Config
from utils import sqs
from services import jobs


app = Flask(__name__)
app.config.from_object(Config())
db.init_app(app)


@app.route("/", methods=['GET'])
def handler():
    print(1)
    return 'hello world'


# @app.route("/send_message", methods=['GET'])
# def send_message_to_queue():
#     response = sqs.send_message('Hi')
#     return response


@app.route("/run_job", methods=['GET'])
def run_job():
    response = jobs.check_and_run_job()
    return '2222'


if __name__ == '__main__':
    app.run(debug=True)