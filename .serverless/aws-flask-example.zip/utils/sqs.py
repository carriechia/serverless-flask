﻿import boto3
import json
from config import Config
import uuid


def send_message(data):
    deduplicationId = str(uuid.uuid1())
    sqs_client = boto3.client("sqs", region_name="us-east-1")

    response = sqs_client.send_message(
        MessageGroupId=str(1),
        QueueUrl="https://sqs.us-east-1.amazonaws.com/088232242632/TestQueue.fifo",
        MessageBody=json.dumps(data),
        MessageDeduplicationId=deduplicationId
    )
    # print(response)
    return response


def create_queue():
    sqs_client = boto3.client("sqs", region_name="us-east-1")
    response = sqs_client.create_queue(
        QueueName="TestQueue.fifo",
        Attributes={
            "DelaySeconds": "0",
            "VisibilityTimeout": "60",  # 60 seconds
        }
    )
    print(response)