﻿import requests

def lambda_handler(event, context):
    for record in event['Records']:
        payload = record["body"]

        headers = {
        'Authorization': 'Bearer QQtzh0zAgbBP2G7tGzUKr8qllTp7sLA1636fD8qDoxx',
        'Content-Type': 'application/x-www-form-urlencoded'
        }
        r = requests.post('https://notify-api.line.me/api/notify',
                      headers=headers,
                      data={'message': 'Hello', 'body_message': str(payload)})